import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Shield } from 'lucide-react';
import Home from './pages/Home';
import QueryAnalysis from './pages/QueryAnalysis';
import AttackLogs from './pages/AttackLogs';
import Dashboard from './pages/Dashboard';
import LiveMonitoring from './pages/LiveMonitoring';
import ApiDocs from './pages/ApiDocs';
import AdminSettings from './pages/AdminSettings';
import Honeypot from './pages/Honeypot';
import Chatbot from './pages/Chatbot';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 text-white">
        <header className="border-b border-gray-700">
          <div className="container mx-auto px-6 py-4">
            <div className="flex items-center justify-between">
              <Link to="/" className="flex items-center space-x-3">
                <Shield className="h-8 w-8 text-blue-400" />
                <h1 className="text-2xl font-bold">SQL Guardian AI</h1>
              </Link>
              <nav>
                <ul className="flex space-x-6">
                  <li><Link to="/analyze" className="hover:text-blue-400 transition-colors">Analysis</Link></li>
                  <li><Link to="/dashboard" className="hover:text-blue-400 transition-colors">Dashboard</Link></li>
                  <li><Link to="/logs" className="hover:text-blue-400 transition-colors">Logs</Link></li>
                  <li><Link to="/live-monitoring" className="hover:text-blue-400 transition-colors">Live</Link></li>
                  <li><Link to="/api-docs" className="hover:text-blue-400 transition-colors">API</Link></li>
                  <li><Link to="/admin/settings" className="hover:text-blue-400 transition-colors">Admin</Link></li>
                </ul>
              </nav>
            </div>
          </div>
        </header>

        <main className="container mx-auto px-6 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/analyze" element={<QueryAnalysis />} />
            <Route path="/logs" element={<AttackLogs />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/live-monitoring" element={<LiveMonitoring />} />
            <Route path="/api-docs" element={<ApiDocs />} />
            <Route path="/admin/settings" element={<AdminSettings />} />
            <Route path="/honeypot" element={<Honeypot />} />
            <Route path="/chatbot" element={<Chatbot />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;