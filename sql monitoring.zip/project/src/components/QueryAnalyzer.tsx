import React, { useState } from 'react';
import { AlertTriangle, CheckCircle } from 'lucide-react';

function QueryAnalyzer() {
  const [query, setQuery] = useState('');
  const [riskScore, setRiskScore] = useState<number | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  const analyzeQuery = () => {
    // Simulated analysis - in production, this would call your ML service
    const score = Math.random() * 100;
    setRiskScore(score);
    setAnalysisResult(score > 70 ? 'High Risk - Potential SQL Injection Detected' : 
                     score > 30 ? 'Medium Risk - Suspicious Patterns Found' : 
                     'Low Risk - Query Appears Safe');
  };

  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
      <h2 className="text-xl font-semibold mb-4">Query Analysis</h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Enter SQL Query</label>
          <textarea
            className="w-full h-32 px-3 py-2 text-gray-900 bg-white rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="SELECT * FROM users WHERE id = '1'"
          />
        </div>
        <button
          onClick={analyzeQuery}
          className="px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg font-medium transition-colors"
        >
          Analyze Query
        </button>
      </div>

      {riskScore !== null && (
        <div className="mt-6 space-y-4">
          <div className="bg-gray-700 rounded-lg p-4">
            <h3 className="text-lg font-medium mb-2">Analysis Results</h3>
            <div className="flex items-center space-x-2">
              {riskScore > 70 ? (
                <AlertTriangle className="h-5 w-5 text-red-500" />
              ) : riskScore > 30 ? (
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
              ) : (
                <CheckCircle className="h-5 w-5 text-green-500" />
              )}
              <span>{analysisResult}</span>
            </div>
            <div className="mt-4">
              <div className="h-2 w-full bg-gray-600 rounded-full overflow-hidden">
                <div
                  className={`h-full ${
                    riskScore > 70
                      ? 'bg-red-500'
                      : riskScore > 30
                      ? 'bg-yellow-500'
                      : 'bg-green-500'
                  }`}
                  style={{ width: `${riskScore}%` }}
                />
              </div>
              <div className="mt-2 text-sm text-gray-400">
                Risk Score: {riskScore.toFixed(1)}%
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default QueryAnalyzer;