import React from 'react';
import { Code, Copy } from 'lucide-react';

function ApiDocs() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">API Documentation</h1>

      <div className="space-y-8">
        <section className="bg-gray-800 rounded-lg p-6 shadow-xl">
          <h2 className="text-xl font-semibold mb-4">Getting Started</h2>
          <p className="text-gray-300 mb-4">
            The SQL Guardian API allows you to integrate our SQL injection detection and prevention
            system into your applications. All API endpoints are accessible via HTTPS and return
            JSON responses.
          </p>
          
          <div className="bg-gray-900 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-blue-400 font-mono">Base URL</span>
              <button className="text-gray-400 hover:text-white">
                <Copy className="h-4 w-4" />
              </button>
            </div>
            <code className="text-green-400">
              https://api.sqlguardian.com/v1
            </code>
          </div>
        </section>

        <section className="bg-gray-800 rounded-lg p-6 shadow-xl">
          <h2 className="text-xl font-semibold mb-4">Authentication</h2>
          <p className="text-gray-300 mb-4">
            All API requests require an API key to be included in the Authorization header.
          </p>
          
          <div className="bg-gray-900 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-blue-400 font-mono">Authorization Header</span>
              <button className="text-gray-400 hover:text-white">
                <Copy className="h-4 w-4" />
              </button>
            </div>
            <code className="text-green-400">
              Authorization: Bearer your-api-key
            </code>
          </div>
        </section>

        <section className="bg-gray-800 rounded-lg p-6 shadow-xl">
          <h2 className="text-xl font-semibold mb-4">Endpoints</h2>
          
          <div className="space-y-6">
            <EndpointDoc
              method="POST"
              endpoint="/analyze"
              description="Analyze a SQL query for potential injection attacks"
              request={{
                query: "SELECT * FROM users WHERE id = '1'",
                context: "authentication"
              }}
              response={{
                risk_score: 85,
                is_malicious: true,
                detected_patterns: ["union-based", "boolean-based"],
                sanitized_query: "SELECT * FROM users WHERE id = ?"
              }}
            />

            <EndpointDoc
              method="GET"
              endpoint="/logs"
              description="Retrieve attack detection logs"
              request={{
                from: "2024-03-01",
                to: "2024-03-15",
                limit: 100
              }}
              response={{
                total: 1420,
                attacks: 142,
                logs: [
                  {
                    timestamp: "2024-03-15T14:30:00Z",
                    query: "SELECT * FROM users WHERE id = '1'",
                    risk_score: 85,
                    ip: "192.168.1.100"
                  }
                ]
              }}
            />
          </div>
        </section>
      </div>
    </div>
  );
}

function EndpointDoc({ method, endpoint, description, request, response }: {
  method: string;
  endpoint: string;
  description: string;
  request: object;
  response: object;
}) {
  return (
    <div className="border border-gray-700 rounded-lg overflow-hidden">
      <div className="bg-gray-700 p-4">
        <div className="flex items-center space-x-3">
          <span className={`px-2 py-1 rounded text-sm font-mono ${
            method === 'GET' ? 'bg-green-500/20 text-green-400' :
            method === 'POST' ? 'bg-blue-500/20 text-blue-400' :
            'bg-yellow-500/20 text-yellow-400'
          }`}>
            {method}
          </span>
          <span className="font-mono text-gray-300">{endpoint}</span>
        </div>
        <p className="mt-2 text-sm text-gray-300">{description}</p>
      </div>
      
      <div className="p-4 space-y-4">
        <div>
          <div className="flex items-center space-x-2 mb-2">
            <Code className="h-4 w-4 text-blue-400" />
            <h4 className="font-medium">Request</h4>
          </div>
          <pre className="bg-gray-900 p-3 rounded-lg overflow-x-auto">
            <code className="text-green-400">
              {JSON.stringify(request, null, 2)}
            </code>
          </pre>
        </div>
        
        <div>
          <div className="flex items-center space-x-2 mb-2">
            <Code className="h-4 w-4 text-blue-400" />
            <h4 className="font-medium">Response</h4>
          </div>
          <pre className="bg-gray-900 p-3 rounded-lg overflow-x-auto">
            <code className="text-green-400">
              {JSON.stringify(response, null, 2)}
            </code>
          </pre>
        </div>
      </div>
    </div>
  );
}

export default ApiDocs;