import React from 'react';
import { AlertTriangle, Shield, Clock } from 'lucide-react';

const mockLogs = [
  {
    id: 1,
    timestamp: '2024-03-15T14:30:00Z',
    query: "SELECT * FROM users WHERE username = '' OR '1'='1'",
    risk: 95,
    ip: '192.168.1.100',
    status: 'Blocked'
  },
  {
    id: 2,
    timestamp: '2024-03-15T14:25:00Z',
    query: "SELECT * FROM products WHERE id = '1' UNION SELECT username,password FROM users",
    risk: 88,
    ip: '192.168.1.101',
    status: 'Blocked'
  },
  {
    id: 3,
    timestamp: '2024-03-15T14:20:00Z',
    query: "SELECT * FROM orders WHERE user_id = 1",
    risk: 15,
    ip: '192.168.1.102',
    status: 'Allowed'
  }
];

function AttackLogs() {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Attack Logs</h1>
        <div className="flex items-center space-x-4">
          <span className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-400" />
            <span>Last 24 hours</span>
          </span>
          <button className="px-4 py-2 bg-blue-500 hover:bg-blue-600 rounded-lg">
            Export Logs
          </button>
        </div>
      </div>

      <div className="bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-700">
              <th className="px-6 py-3 text-left text-sm font-semibold">Timestamp</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Query</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Risk Score</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">IP Address</th>
              <th className="px-6 py-3 text-left text-sm font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {mockLogs.map((log) => (
              <tr key={log.id} className="hover:bg-gray-750">
                <td className="px-6 py-4 text-sm">
                  {new Date(log.timestamp).toLocaleString()}
                </td>
                <td className="px-6 py-4 text-sm font-mono">{log.query}</td>
                <td className="px-6 py-4">
                  <div className="flex items-center space-x-2">
                    {log.risk > 70 ? (
                      <AlertTriangle className="h-4 w-4 text-red-500" />
                    ) : (
                      <Shield className="h-4 w-4 text-green-500" />
                    )}
                    <span className={log.risk > 70 ? 'text-red-500' : 'text-green-500'}>
                      {log.risk}%
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm">{log.ip}</td>
                <td className="px-6 py-4">
                  <span
                    className={`px-2 py-1 text-xs rounded-full ${
                      log.status === 'Blocked'
                        ? 'bg-red-500/20 text-red-400'
                        : 'bg-green-500/20 text-green-400'
                    }`}
                  >
                    {log.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AttackLogs;