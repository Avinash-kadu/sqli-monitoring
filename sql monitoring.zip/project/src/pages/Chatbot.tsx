import React, { useState } from 'react';
import { Send, Bot, User } from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      type: 'bot',
      content: "Hello! I'm your SQL Guardian AI assistant. How can I help you with SQL injection prevention today?",
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');

  const handleSend = () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Simulate bot response
    setTimeout(() => {
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: generateBotResponse(input),
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="h-[calc(100vh-12rem)]">
      <div className="flex flex-col h-full bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        <div className="bg-gray-700 p-4 border-b border-gray-600">
          <div className="flex items-center space-x-3">
            <Bot className="h-6 w-6 text-blue-400" />
            <div>
              <h2 className="font-semibold">SQL Guardian Assistant</h2>
              <p className="text-sm text-gray-400">Online</p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map(message => (
            <div
              key={message.id}
              className={`flex items-start space-x-3 ${
                message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
              }`}
            >
              <div className={`p-2 rounded-full ${
                message.type === 'user' ? 'bg-blue-500' : 'bg-gray-700'
              }`}>
                {message.type === 'user' ? (
                  <User className="h-5 w-5" />
                ) : (
                  <Bot className="h-5 w-5" />
                )}
              </div>
              <div className={`max-w-[70%] ${
                message.type === 'user' ? 'bg-blue-500' : 'bg-gray-700'
              } rounded-lg p-3`}>
                <p className="text-sm">{message.content}</p>
                <span className="text-xs text-gray-400 mt-1 block">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-gray-700">
          <div className="flex space-x-3">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask me about SQL injection prevention..."
              className="flex-1 bg-gray-700 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
              rows={1}
            />
            <button
              onClick={handleSend}
              className="p-2 bg-blue-500 hover:bg-blue-600 rounded-lg transition-colors"
            >
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function generateBotResponse(input: string): string {
  const responses = [
    "SQL injection typically occurs when user input is not properly sanitized. Always use parameterized queries to prevent this.",
    "One common prevention technique is to use an ORM (Object-Relational Mapping) which automatically handles query sanitization.",
    "Input validation is crucial. Make sure to validate and sanitize all user inputs before using them in SQL queries.",
    "Using prepared statements is one of the most effective ways to prevent SQL injection attacks.",
    "Regular security audits and penetration testing can help identify potential SQL injection vulnerabilities in your application."
  ];
  
  return responses[Math.floor(Math.random() * responses.length)];
}

export default Chatbot;