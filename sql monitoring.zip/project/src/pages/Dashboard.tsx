import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Shield, AlertTriangle, Activity } from 'lucide-react';

const mockData = [
  { name: '00:00', attacks: 12 },
  { name: '03:00', attacks: 19 },
  { name: '06:00', attacks: 3 },
  { name: '09:00', attacks: 5 },
  { name: '12:00', attacks: 2 },
  { name: '15:00', attacks: 13 },
  { name: '18:00', attacks: 22 },
  { name: '21:00', attacks: 8 },
];

function Dashboard() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Security Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <StatCard
          icon={<Shield className="h-6 w-6 text-green-400" />}
          title="Total Queries"
          value="23,492"
          subtitle="Last 24 hours"
        />
        <StatCard
          icon={<AlertTriangle className="h-6 w-6 text-red-400" />}
          title="Attacks Blocked"
          value="142"
          subtitle="Last 24 hours"
        />
        <StatCard
          icon={<Activity className="h-6 w-6 text-blue-400" />}
          title="Average Risk Score"
          value="18.3%"
          subtitle="Last 24 hours"
        />
      </div>

      <div className="bg-gray-800 rounded-lg p-6 shadow-xl mb-8">
        <h2 className="text-xl font-semibold mb-4">Attack Frequency</h2>
        <div className="h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={mockData}>
              <defs>
                <linearGradient id="attacksGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#3B82F6" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1F2937',
                  border: 'none',
                  borderRadius: '0.5rem',
                  padding: '1rem',
                }}
              />
              <Area
                type="monotone"
                dataKey="attacks"
                stroke="#3B82F6"
                fillOpacity={1}
                fill="url(#attacksGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, title, value, subtitle }: {
  icon: React.ReactNode;
  title: string;
  value: string;
  subtitle: string;
}) {
  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
      <div className="flex items-center space-x-3 mb-3">
        {icon}
        <h3 className="font-semibold">{title}</h3>
      </div>
      <p className="text-3xl font-bold mb-1">{value}</p>
      <p className="text-sm text-gray-400">{subtitle}</p>
    </div>
  );
}

export default Dashboard;