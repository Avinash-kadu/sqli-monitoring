import React from 'react';
import { Activity, Database, Lock } from 'lucide-react';
import QueryAnalyzer from '../components/QueryAnalyzer';

function Home() {
  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <StatsCard
          icon={<Activity className="h-6 w-6 text-green-400" />}
          title="Real-Time Protection"
          description="ML-powered analysis"
        />
        <StatsCard
          icon={<Database className="h-6 w-6 text-blue-400" />}
          title="Query Analysis"
          description="Advanced pattern detection"
        />
        <StatsCard
          icon={<Lock className="h-6 w-6 text-purple-400" />}
          title="Threat Prevention"
          description="Automatic query sanitization"
        />
      </div>
      <QueryAnalyzer />
    </div>
  );
}

function StatsCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
      <div className="flex items-center space-x-3">
        {icon}
        <div>
          <h3 className="font-semibold">{title}</h3>
          <p className="text-sm text-gray-400">{description}</p>
        </div>
      </div>
    </div>
  );
}

export default Home;