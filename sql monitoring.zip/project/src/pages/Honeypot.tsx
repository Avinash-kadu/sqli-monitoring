import React, { useState, useEffect } from 'react';
import { Bug, AlertTriangle, Activity } from 'lucide-react';

interface AttackPattern {
  id: string;
  pattern: string;
  frequency: number;
  firstSeen: Date;
  lastSeen: Date;
  risk: number;
}

function Honeypot() {
  const [patterns, setPatterns] = useState<AttackPattern[]>([]);

  useEffect(() => {
    // Simulate loading attack patterns
    setPatterns([
      {
        id: '1',
        pattern: "UNION SELECT password FROM users",
        frequency: 45,
        firstSeen: new Date('2024-03-01'),
        lastSeen: new Date('2024-03-15'),
        risk: 95
      },
      {
        id: '2',
        pattern: "' OR '1'='1",
        frequency: 78,
        firstSeen: new Date('2024-03-05'),
        lastSeen: new Date('2024-03-15'),
        risk: 90
      },
      {
        id: '3',
        pattern: "SLEEP(5)",
        frequency: 23,
        firstSeen: new Date('2024-03-10'),
        lastSeen: new Date('2024-03-15'),
        risk: 85
      }
    ]);
  }, []);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center space-x-3">
          <h1 className="text-3xl font-bold">Honeypot System</h1>
          <span className="px-2 py-1 text-xs bg-green-500/20 text-green-400 rounded-full flex items-center space-x-1">
            <Activity className="h-4 w-4" />
            <span>Active</span>
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <StatCard
          icon={<Bug className="h-6 w-6 text-red-400" />}
          title="Attack Patterns"
          value="127"
          subtitle="Unique patterns detected"
        />
        <StatCard
          icon={<Activity className="h-6 w-6 text-blue-400" />}
          title="Daily Hits"
          value="1,234"
          subtitle="Average daily attempts"
        />
        <StatCard
          icon={<AlertTriangle className="h-6 w-6 text-yellow-400" />}
          title="Learning Rate"
          value="92%"
          subtitle="Pattern recognition"
        />
      </div>

      <div className="bg-gray-800 rounded-lg shadow-xl overflow-hidden">
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-4">Detected Attack Patterns</h2>
          <div className="space-y-4">
            {patterns.map(pattern => (
              <div key={pattern.id} className="border border-gray-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <Bug className="h-5 w-5 text-red-400" />
                    <code className="text-sm bg-gray-900 px-2 py-1 rounded">
                      {pattern.pattern}
                    </code>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${
                    pattern.risk > 90 ? 'bg-red-500/20 text-red-400' :
                    pattern.risk > 70 ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-green-500/20 text-green-400'
                  }`}>
                    Risk: {pattern.risk}%
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm text-gray-400">
                  <div>
                    <span className="block text-gray-500">Frequency</span>
                    {pattern.frequency} times
                  </div>
                  <div>
                    <span className="block text-gray-500">First Seen</span>
                    {pattern.firstSeen.toLocaleDateString()}
                  </div>
                  <div>
                    <span className="block text-gray-500">Last Seen</span>
                    {pattern.lastSeen.toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, title, value, subtitle }: {
  icon: React.ReactNode;
  title: string;
  value: string;
  subtitle: string;
}) {
  return (
    <div className="bg-gray-800 rounded-lg p-6 shadow-xl">
      <div className="flex items-center space-x-3 mb-3">
        {icon}
        <h3 className="font-semibold">{title}</h3>
      </div>
      <p className="text-3xl font-bold mb-1">{value}</p>
      <p className="text-sm text-gray-400">{subtitle}</p>
    </div>
  );
}

export default Honeypot;