import React, { useState, useEffect } from 'react';
import { AlertTriangle, Shield, Activity } from 'lucide-react';

interface QueryEvent {
  id: string;
  timestamp: Date;
  query: string;
  risk: number;
  ip: string;
  status: 'Blocked' | 'Allowed';
}

function LiveMonitoring() {
  const [events, setEvents] = useState<QueryEvent[]>([]);

  useEffect(() => {
    // Simulate real-time events
    const interval = setInterval(() => {
      const newEvent: QueryEvent = {
        id: Math.random().toString(36).substr(2, 9),
        timestamp: new Date(),
        query: generateRandomQuery(),
        risk: Math.floor(Math.random() * 100),
        ip: generateRandomIP(),
        status: Math.random() > 0.7 ? 'Blocked' : 'Allowed'
      };

      setEvents(prev => [newEvent, ...prev].slice(0, 10));
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Live Monitoring</h1>
        <div className="flex items-center space-x-2">
          <Activity className="h-5 w-5 text-green-400 animate-pulse" />
          <span className="text-green-400">Live</span>
        </div>
      </div>

      <div className="space-y-4">
        {events.map(event => (
          <div
            key={event.id}
            className="bg-gray-800 rounded-lg p-4 shadow-xl animate-fadeIn"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-3">
                {event.risk > 70 ? (
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                ) : (
                  <Shield className="h-5 w-5 text-green-500" />
                )}
                <span className="text-sm text-gray-400">
                  {event.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <span
                className={`px-2 py-1 text-xs rounded-full ${
                  event.status === 'Blocked'
                    ? 'bg-red-500/20 text-red-400'
                    : 'bg-green-500/20 text-green-400'
                }`}
              >
                {event.status}
              </span>
            </div>
            <div className="font-mono text-sm mb-2">{event.query}</div>
            <div className="flex justify-between items-center text-sm text-gray-400">
              <span>IP: {event.ip}</span>
              <span className={event.risk > 70 ? 'text-red-400' : 'text-green-400'}>
                Risk Score: {event.risk}%
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function generateRandomQuery(): string {
  const queries = [
    "SELECT * FROM users WHERE id = '1' OR '1'='1'",
    "SELECT * FROM products WHERE category = 'electronics'",
    "INSERT INTO logs (user_id, action) VALUES (1, 'login')",
    "SELECT * FROM orders WHERE status = 'pending'",
    "UPDATE users SET last_login = NOW() WHERE id = 1",
  ];
  return queries[Math.floor(Math.random() * queries.length)];
}

function generateRandomIP(): string {
  return Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.');
}

export default LiveMonitoring;