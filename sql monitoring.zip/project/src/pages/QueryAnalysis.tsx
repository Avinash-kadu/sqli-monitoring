import React from 'react';
import QueryAnalyzer from '../components/QueryAnalyzer';

function QueryAnalysis() {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Advanced Query Analysis</h1>
      <QueryAnalyzer />
    </div>
  );
}

export default QueryAnalysis;